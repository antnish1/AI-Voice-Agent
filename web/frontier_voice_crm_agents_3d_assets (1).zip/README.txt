Frontier Voice CRM — AI Voice Agents 3D Artwork

Upload the contents of public/assets/agents/ into the matching directory in your GitHub repository.
All 12 files are WebP images with transparent backgrounds.
Header robot: 800x800. Header voice and KPI icons: 256x256. Agent card images: 512x512.

Note: These are newly generated illustrations matching the requested style, not pixel-exact extracts from the original screenshot.

No code, GitHub repository, or deployment was changed when creating this asset package.
